import React, { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { FAQsData } from '../utils/FAQsData';

const FAQItem = ({ question, answer, index }) => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleOpen = () => {
        setIsOpen(!isOpen);
        // setIsOpen(index === isOpen ? null : index);
    };

    const ref=useRef();
    const isInView=useInView(ref,{once:true});

    return (
        <motion.div
            ref={ref}
            initial={{ y: '10vh', opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 1.5, ease: 'easeInOut' }}
            className={`border border-blue-300 rounded-md transition-all faq duration-700`}>
            <div
                onClick={toggleOpen}
                // onClick={()=>toggleOpen(index)}
                className={`flex justify-between items-center rounded-md p-6 bg-blue-50 cursor-pointer hover:bg-blue-200 transition duration-700 `}
            >
                <h4 className="font-medium text-lg text-blue-500 font-roboto">{question}</h4>
                <span className=" text-5xl font-thin text-blue-500">{isOpen ? '-' : '+'}</span>
            </div>
            {isOpen && (
                <div className="p-4 bg-blue-50 rounded-md duration-700">
                    <p className="text-gray-700 text-lg font-roboto px-4">{answer}</p>
                </div>
            )}
        </motion.div>
    );
};

const FAQs = () => {
    const ref=useRef();
    const isInView=useInView(ref,{once:true});
    return (
        <div className='py-20'>
            <motion.div 
            ref={ref}
            initial={{ y: '-10vh', opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 1.5, ease: 'easeInOut' }}
            className=' w-full px-[1rem] mx-auto'>
                <h3 className=' text-xl sm:text-2xl text-center font-semibold text-orange-500 font-roboto'>FAQ's</h3>
                <h1 className=' text-2xl sm:text-4xl text-slate-700 w-full sm:w-[43%] mx-auto text-center font-bold font-roboto my-4'>Frequently Asked Questions</h1>
                <p className='text-lg font-roboto text-slate-600 md:w-[45%] mx-auto text-center'>
                    Build responsive, mobile-first projects on the web with the world's most popular front-end component library.
                </p>
            </motion.div>

            <div className='w-[95%] overflow-hidden md:w-[80%] grid grid-cols-1 lg:grid-cols-2 gap-8 mx-auto my-12'>
                {FAQsData?.map((faq, index) => (
                    <FAQItem
                        key={index}
                        question={faq?.question}
                        answer={faq?.answer}
                        index={index + 1}
                    />
                ))}
            </div>
        </div>
    );
}

export default FAQs;

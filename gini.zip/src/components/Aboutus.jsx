import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import PageBanner from "../common/PageBanner";
import mission from '../assets/other/mission.png';
import aboutus from '../assets/other/About us.jpg';
import Services from "./Services";
import WhyChooseUs from "./WhyChooseUs";
// Who We Are Component
const WhoWeAre = () => {
    const ref = useRef();
    const isInView = useInView(ref, { once: true });
    return (
        <section className="py-10 flex justify-center items-center flex-col md:flex-row px-[2rem] lg:px-[8rem] gap-8 ">
            <motion.div
                ref={ref}
                initial={{ x: '-10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className="w-full lg:w-[50%]">
                <h2 className="text-3xl font-semibold font-roboto mb-4">Who We Are</h2>
                <p className="text-lg text-gray-600 font-roboto">
                    At Gini, we are a team of passionate innovators and technology experts dedicated to helping businesses succeed in the digital era. With a deep understanding of software development, we specialize in creating custom solutions—from web and mobile apps to cloud infrastructure—that address unique business challenges. Our commitment to innovation ensures we stay ahead of trends, delivering cutting-edge technology that drives growth, efficiency, and transformation.
                </p>
                <p className="text-lg text-gray-600 font-roboto">
                    What sets us apart is our client-first approach. We work closely with each client to understand their vision and craft tailored solutions that not only meet immediate needs but also position them for long-term success in an evolving digital landscape.
                </p>
            </motion.div>
            <motion.div
                ref={ref}
                initial={{ x: '10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className="w-full lg:w-[50%]">
                <img src={aboutus} alt="About Us Image" />
            </motion.div>

        </section>
    );
};

// Our Mission Component
const OurMission = () => {
    const ref = useRef();
    const isInView = useInView(ref, { once: true });
    return (
        <section className="py-10 px-[2rem] lg:px-[8rem] bg-gray-100 flex justify-center items-center gap-4 flex-col md:flex-row ">
            <motion.div
                ref={ref}
                initial={{ x: '-10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className="w-full lg:w-[50%]">
                <img src={mission} alt="Our Mission" />
            </motion.div>

            <motion.div
                ref={ref}
                initial={{ x: '10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className="w-full lg:w-[50%]">
                <h2 className="text-3xl font-roboto font-semibold mb-4">Our Mission</h2>
                <p className="text-lg text-gray-600 font-roboto">
                    At Gini, our mission is to empower businesses with innovative, scalable, and transformative technology solutions. We aim to turn complex challenges into streamlined opportunities by delivering cutting-edge software that drives growth, enhances efficiency, and fosters success. Our commitment to quality, collaboration, and excellence ensures that we build digital ecosystems that are not only secure but adaptable to the ever-evolving market landscape. We strive to be a trusted partner in your digital transformation journey, helping you achieve lasting success in the modern world.
                </p>
            </motion.div>

        </section>
    );
};

// What We Do Component
const WhatWeDo = () => {
    const services = [
        { title: "App Development", description: "We create custom mobile applications that deliver seamless user experiences." },
        { title: "Web Development", description: "Beautiful, responsive websites that engage and convert." },
        { title: "Cloud Solutions", description: "Scalable, secure cloud infrastructure to meet growing demands." },
        { title: "Digital Marketing", description: "Data-driven strategies to enhance your online presence and visibility." },
        { title: "Bulk SMS", description: "Fast, reliable communication services to connect with your customers instantly." },
        { title: "IT Consulting", description: "Expert guidance to align your technology with business goals." },
    ];

    return (
        <section className="py-10 px-5 text-center">
            <h2 className="text-3xl font-semibold mb-8">What We Do</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {services.map((service, index) => (
                    <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
                        <h3 className="text-xl font-bold mb-4">{service.title}</h3>
                        <p className="text-gray-600">{service.description}</p>
                    </div>
                ))}
            </div>
        </section>
    );
};

// Why Choose Us Component
// const WhyChooseUs = () => {
//     const reasons = [
//         "Expert Team: Our experienced team brings technical expertise and creative problem-solving to every project.",
//         "Client-Centric: We focus on understanding your unique business needs and provide personalized solutions.",
//         "Innovative Solutions: Leveraging the latest technology to create future-proof systems that grow with your business.",
//         "24/7 Support: Our dedicated support team ensures your systems run smoothly with around-the-clock assistance.",
//     ];

//     return (
//         <section className="py-10 px-5 bg-gray-100 text-center">
//             <h2 className="text-3xl font-semibold mb-8">Why Choose Gini</h2>
//             <ul className="space-y-6">
//                 {reasons.map((reason, index) => (
//                     <li key={index} className="text-lg text-gray-600">
//                         {reason}
//                     </li>
//                 ))}
//             </ul>
//         </section>
//     );
// };

// Our Values Component
const OurValues = () => {
    const values = [
        { title: "Innovation", description: "We embrace the latest technology to push boundaries." },
        { title: "Quality", description: "We deliver high-performance, reliable solutions that exceed expectations." },
        { title: "Integrity", description: "We believe in building trust through transparency and accountability." },
        { title: "Collaboration", description: "We partner with clients, creating solutions that address real business needs." },
    ];

    return (
        <section className="py-10 px-5 text-center">
            <h2 className="text-3xl font-semibold mb-8">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {values.map((value, index) => (
                    <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
                        <h3 className="text-xl font-bold mb-4">{value.title}</h3>
                        <p className="text-gray-600">{value.description}</p>
                    </div>
                ))}
            </div>
        </section>
    );
};

// Our Journey Component
const OurJourney = () => {
    return (
        <section className="py-10 px-5 bg-gray-100 text-center">
            <h2 className="text-3xl font-semibold mb-4">Our Journey</h2>
            <p className="text-lg text-gray-600">
                Since our beginning, Gini has helped businesses across industries—from
                startups to large enterprises—solve their technology challenges. Our
                commitment to quality and collaboration has resulted in long-term client
                relationships and impactful solutions.
            </p>
        </section>
    );
};

// Call to Action Component
const CallToAction = () => {
    return (
        <section className="py-10 px-5 text-center bg-indigo-600 text-white">
            <h2 className="text-3xl font-semibold mb-4">Let’s Build the Future Together</h2>
            <p className="text-lg mb-6">
                Whether you need a reliable technology partner or want to innovate with
                cutting-edge solutions, Gini is here to help. Let’s transform your ideas
                into powerful solutions that drive your business forward.
            </p>
            <button className="bg-white text-indigo-600 font-bold py-3 px-6 rounded-md shadow-md hover:bg-gray-100">
                Contact Us Today
            </button>
        </section>
    );
};

// Main About Us Component (that combines all components)
const AboutUs = () => {
    return (
        <div className=" about-us-container">
            <PageBanner
                title={'About Us'}
                desc={`Welcome to Gini – where innovation meets excellence. We provide top-quality solutions tailored to your needs, driving success with passion and expertise.`}
            />
            <WhoWeAre />
            <OurMission />
            {/* <WhatWeDo /> */}
            <Services />
            <div className="px-[2rem] py-5 md:px-[8rem]">
                <WhyChooseUs />
            </div>
            {/* <OurValues /> */}
            {/* <OurJourney /> */}
            {/* <CallToAction /> */}
        </div>
    );
};

export default AboutUs;

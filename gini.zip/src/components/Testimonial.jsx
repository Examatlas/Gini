import React from 'react';
// import TestimonialSlider from './TestimonialSlider';
import TestimonialSlider from './TestimonialSlider';

const Testimonial = () => {
  return (
    <div className='bg-blue-800 bg-opacity-0 testimonial py-20'>
      <div>
        <div className=' w-full mx-auto'>
          <h3 className=' text-xl sm:text-2xl text-center font-semibold text-orange-500 font-roboto'>Testimonials</h3>
          <h1 className=' text-2xl sm:text-4xl text-gray-100 w-full sm:w-[43%] mx-auto text-center font-bold font-roboto my-4'>Our Client Recent Feedback</h1>
        </div>

        <div className='w-[98%] xl:w-[85%] mx-auto '>
          <TestimonialSlider/>
        </div>
      </div>
    </div>
  );
}

export default Testimonial;

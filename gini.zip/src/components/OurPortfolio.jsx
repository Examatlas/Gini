import React from 'react';
import OurProductCard from '../common/OurProductCard';
import PortfolioCard from '../common/PortfolioCard';

const OurPortfolio = () => {
    return (
        <div>
            <div className=' w-full mx-auto'>
                <h3 className=' text-xl sm:text-2xl text-center font-semibold text-orange-500 font-roboto'>Our Portfolio</h3>
                <h1 className=' text-2xl sm:text-4xl w-full sm:w-[43%] mx-auto text-center font-bold text-slate-800 font-roboto my-4'>
                Work & Project
                </h1>
                <p className='text-center md:w-[50%] mx-auto text-slate-700'>
                    Build responsive, mobile-first projects on the web with the most popular front-end component library.
                </p>
            </div>

            <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 lg:px-[8rem] px-[2rem] gap-8 my-10'>
                {/* <OurProductCard/> */}
                <PortfolioCard 
                title={`E-Commerce Platform for XYZ`}
                description={`Developed a scalable, responsive e-commerce solution with advanced analytics and integrated payment systems.`}
                techStack={`React, Node.js, MongoDB`}
                ctaText={`View Project`}
                image={`https://via.placeholder.com/400x300`}
                /> 
                <PortfolioCard 
                title={`E-Commerce Platform for XYZ`}
                description={`Developed a scalable, responsive e-commerce solution with advanced analytics and integrated payment systems.`}
                techStack={`React, Node.js, MongoDB`}
                ctaText={`View Project`}
                image={`https://via.placeholder.com/400x300`}
                /> 
                <PortfolioCard 
                title={`E-Commerce Platform for XYZ`}
                description={`Developed a scalable, responsive e-commerce solution with advanced analytics and integrated payment systems.`}
                techStack={`React, Node.js, MongoDB`}
                ctaText={`View Project`}
                image={`https://via.placeholder.com/400x300`}
                /> 
                <PortfolioCard 
                title={`E-Commerce Platform for XYZ`}
                description={`Developed a scalable, responsive e-commerce solution with advanced analytics and integrated payment systems.`}
                techStack={`React, Node.js, MongoDB`}
                ctaText={`View Project`}
                image={`https://via.placeholder.com/400x300`}
                /> 
                {/* <OurProductCard/>
                <OurProductCard/>
                <OurProductCard/>
                <OurProductCard/>
                <OurProductCard/>
                <OurProductCard/>
                <OurProductCard/> */}
            </div>

        </div>
    );
}

export default OurPortfolio;

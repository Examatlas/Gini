import React from 'react';

import Logo from '../assets/logo-removebg-preview.png'
import Button from '../common/Button';
import { FaFacebook, FaInstagram, FaLinkedin, FaLocationDot, FaPhone, FaXTwitter, FaYoutube } from 'react-icons/fa6';
import { IoMail, } from 'react-icons/io5';
import { Link } from 'react-router-dom';

const Footer = () => {
    return (
        <div className=' bg-blue-900  text-white'>
            <div className=' py-5 md:py-20 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 px-[1rem] md:px-[5rem]'>
                <div className='mx-4 '>
                    <div className="logo my-4 flex justify-start items-center">
                        <img
                            src={Logo}
                            alt="Logo"
                            className="w-12 h-12"
                        />
                        <span className='text-3xl font-roboto'>GINI</span>
                    </div>
                    <p className='text-lg font-roboto text-gray-200'>
                        We have 14+ years experience. Helping you overcome technology challenges. Join the thriving technox it solution agency.
                    </p>
                    <Button ButtonValue={'Request a Demo'} />
                    <h2 className='text-2xl font-roboto font-bold'>Our Social Info</h2>
                    <div className='flex gap-5 my-4'>
                        <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                            <FaFacebook className='text-xl text-white' />
                        </div>
                        <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                            <FaXTwitter className='text-xl text-white' />
                        </div>
                        <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                            <FaInstagram className='text-xl text-white' />
                        </div>
                        <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                            <FaLinkedin className='text-xl text-white' />
                        </div>
                        <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                            <FaYoutube className='text-xl text-white' />
                        </div>
                    </div>
                </div>

                <div className=' md:px-[4rem] py-4'>
                    <h1 className='text-2xl font-roboto font-bold my-3'>Services</h1>
                    <ul>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>Web Design</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>Web Development</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>Web Development</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>Cloud Services</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>SEO Optimization</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>Digital Marketing</li>
                    </ul>
                </div>
                <div className=' md:px-[4rem] py-4'>
                    <h1 className='text-2xl my-3 font-roboto font-bold'>Information</h1>
                    <ul>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>About</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>Team</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 my-2 cursor-pointer'>Portfolio</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>FAQs</li>
                        <li className='list-disc ml-5 text-lg font-roboto text-gray-200 hover:text-orange-500 cursor-pointer my-2'>Blogs</li>
                    </ul>
                </div>
                <div className='py-4'>
                    <h1 className='text-2xl font-roboto font-bold my-3'>Contact Us</h1>
                    <div className='flex gap-4 my-4 justify-start items-center'>
                        <FaLocationDot className='text-2xl' />
                        <p className='text-lg font-roboto text-gray-200'>2 Embarcadero Center, San Francisco, CA 94111 USA</p>
                    </div>
                    <div className='flex gap-4 my-4 justify-start items-center'>
                        <FaPhone className='text-xl' />
                        <p className='text-lg font-roboto text-gray-200'>+91 1234567890</p>
                    </div>
                    <div className='flex gap-4 my-4 justify-start items-center'>
                        <IoMail className='text-xl' />
                        <p className='text-lg font-roboto text-gray-200'>support@gini.com</p>
                    </div>
                </div>
            </div>

            <div className='flex md:justify-end px-[1rem] md:px-[4rem] pb-6'>
                {/* <p></p> */}
                <p className='text-lg font-roboto text-gray-200'>
                    <Link to={`/term&condition`} className='hover:text-orange-500 cursor-pointer'>Terms & Conditions</Link> | <Link to={'/privacy-policy'} className='hover:text-orange-500 cursor-pointer'>Privacy Policy</Link>
                </p>
            </div>
        </div>

    );
}

export default Footer;

import React, { useRef } from 'react';
import ProcessCard from '../common/ProcessCard';
import { motion, useInView } from 'framer-motion';
//imagees
import chooseService from '../assets/services/chooseservice.webp';
import meeting from '../assets/services/metting.webp';
import plan from '../assets/services/plan.webp';

const OurProcess = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true })
    return (
        <div className='bg-blue-50 py-16 px-[1rem] md:px-[5rem]'>
            <motion.div
                ref={ref}
                initial={{ y: '30vh', opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : {}}
                transition={{
                    type: 'spring',
                    duration: 1.5,
                    ease: 'easeInOut'
                }}
                className=' w-full mx-auto'>
                <h3 className=' text-xl sm:text-2xl text-center font-semibold text-orange-500 font-roboto'>Our Process</h3>
                <h1 className=' text-2xl sm:text-4xl w-full sm:w-[43%] mx-auto text-center font-bold text-slate-800 font-roboto my-4'>How we help of your business Grow and successful</h1>
            </motion.div>

            <div className='bg-re-400 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 '>
                <ProcessCard
                    icon={chooseService}
                    number={1}
                    title={'Choose a Service'}
                    desc={'Whether you need a full-stack solution, cloud integration, Digital Marketing, or custom software development, we’ve got you covered.'}
                    initialAnimation={{ x: '-10vw', opacity: 0 }}
                    animateAnimation={{ x: 0, opacity: 1 }}
                    transitionConfig={{ duration: 1.5, ease: 'easeInOut' }}
                />
                <ProcessCard
                    icon={meeting}
                    number={2}
                    title={'Request a Meeting'}
                    desc={'In your meeting, we’ll go over your business objectives, technical needs, and project scope, giving you clarity on how we can help.'}
                    initialAnimation={{ y: '10vh', opacity: 0 }}
                    animateAnimation={{ y: 0, opacity: 1 }}
                    transitionConfig={{ duration: 1.5, ease: 'easeInOut' }}
                />
                <ProcessCard
                    icon={plan}
                    number={3}
                    title={'Receive a Custom Plan'}
                    desc={'A detailed project proposal with milestones, technology stack recommendations, and budget transparency.'}
                    initialAnimation={{ x: '10vw', opacity: 0 }}
                    animateAnimation={{ x: 0, opacity: 1 }}
                    transitionConfig={{ duration: 1.5, ease: 'easeInOut' }}
                />
            </div>
        </div>
    );
}

export default OurProcess;

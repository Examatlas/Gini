import React from 'react';
import { blogPosts } from '../utils/BlogData';
import BlogCard from '../common/BlogCard';

const Blogs = () => {
    return (
        <div>

            <div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-8">
                    {blogPosts?.map((post, index) => (
                        <BlogCard
                            key={index}
                            title={post.title}
                            description={post.description}
                            imageUrl={post.imageUrl}
                            date={post.date}
                            link={post.link}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}

export default Blogs;

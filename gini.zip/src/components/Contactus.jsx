import React, { useRef } from 'react';
import Button from '../common/Button';
import { FaFacebook, FaInstagram, FaLinkedin, FaXTwitter, FaYoutube } from 'react-icons/fa6';

import { motion, useInView } from 'framer-motion';

const Contactus = () => {

    const ref = useRef();
    const isInView = useInView(ref, { once: true });
    return (
        <div className='py-20'>

            <motion.div 
            ref={ref}
            initial={{ y: '-10vh', opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 1.5, ease: 'easeInOut' }}
            className=' w-full px-[1rem] mx-auto'>
                <h3 className=' text-xl sm:text-2xl text-center font-semibold text-orange-500 font-roboto'>Get in Touch</h3>
                <h1 className=' text-2xl sm:text-4xl text-slate-700 w-full sm:w-[43%] mx-auto text-center font-bold font-roboto my-4'>Let's start working together</h1>
                <p className='text-lg font-roboto text-slate-600 md:w-[45%] mx-auto text-center'>
                    Build responsive, mobile-first projects on the web with the world's most popular front-end component library.
                </p>
            </motion.div>

            <div className='w-[85%] mx-auto flex flex-col lg:flex-row gap-6 my-16'>
                <motion.form
                    ref={ref}
                    initial={{ x: '-10vw', opacity: 0 }}
                    animate={isInView ? { x: 0, opacity: 1 } : {}}
                    transition={{ duration: 1.5, ease: 'easeInOut' }}
                    action="" className='border p-8 rounded-3xl border-blue-400 w-full lg:w-[70%]'>
                    <div className='flex flex-col md:flex-row gap-8 my-4'>
                        <div className='md:w-1/2 flex flex-col'>
                            <label htmlFor="name" className='text-lg font-roboto mx-2 font-medium'>Name:</label>
                            <input
                                type="text"
                                className='border border-blue-400 px-5 py-3 my-1 rounded-xl text-lg font-roboto outline-none'
                                placeholder='Name'
                                name='name'
                            />
                        </div>
                        <div className=' md:w-1/2 flex flex-col'>
                            <label htmlFor="email" className='text-lg font-roboto mx-2 font-medium'>Email:</label>
                            <input
                                type="email"
                                className='border border-blue-400 px-5 py-3 my-1 rounded-xl text-lg font-roboto outline-none'
                                placeholder='Email Address'
                                name='email'
                            />
                        </div>
                    </div>

                    <div className='w-full flex flex-col my-4'>
                        <label htmlFor="subject" className='text-lg font-roboto mx-2 font-medium'>Subject:</label>
                        <input
                            type="text"
                            className='border border-blue-400 px-5 py-3 my-1 rounded-xl text-lg font-roboto outline-none'
                            placeholder='Write Your Subject'
                            name='subject'
                        />
                    </div>
                    <div className='w-full flex flex-col my-4'>
                        <label htmlFor="message" className='text-lg font-roboto mx-2 font-medium'>Subject:</label>
                        <textarea
                            name="message"
                            className='border border-blue-400 px-5 py-3 my-1 rounded-xl text-lg font-roboto outline-none min-h-[10rem]'
                            id="message"></textarea>
                    </div>

                    <div>
                        <Button ButtonValue={"Send Message"} />
                    </div>

                </motion.form>

                <motion.div
                    ref={ref}
                    initial={{ x: '10vw', opacity: 0 }}
                    animate={isInView ? { x: 0, opacity: 1 } : {}}
                    transition={{ duration: 1.5, ease: 'easeInOut' }}
                    className='w-full lg:w-[30%] bg-blue-600 rounded-3xl p-10 text-white'>
                    <div className='my-4'>
                        <h1 className='text-3xl font-roboto font-semibold'>Our address info</h1>
                        <p className='text-lg font-roboto text-gray-200 leading-6 my-2'>2 Embarcadero Center, San Francisco, CA 94111 USA</p>
                    </div>
                    <div className='my-4'>
                        <h1 className='text-3xl font-roboto font-semibold'>Phone:</h1>
                        <p className='text-lg font-roboto text-gray-200 leading-6 my-2'>+91 1234567890</p>
                        <p className='text-lg font-roboto text-gray-200 leading-6 my-2'>+91 1234567890</p>
                    </div>
                    <div className='my-4'>
                        <h1 className='text-3xl font-roboto font-semibold'>Email:</h1>
                        <p className='text-lg font-roboto text-gray-200 leading-6 my-2'>support@gini.com</p>
                        <p className='text-lg font-roboto text-gray-200 leading-6 my-2'>info@example.com</p>
                    </div>

                    <div className='my-6'>
                        <h1 className='text-3xl font-roboto font-semibold'>Our Social Info</h1>
                        <div className='flex flex-wrap gap-5 my-4'>
                            <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                                <FaFacebook className='text-xl text-white' />
                            </div>
                            <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                                <FaXTwitter className='text-xl text-white' />
                            </div>
                            <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                                <FaInstagram className='text-xl text-white' />
                            </div>
                            <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                                <FaLinkedin className='text-xl text-white' />
                            </div>
                            <div className='p-3 cursor-pointer rounded-full hover:bg-blue-600 bg-blue-800 text-white'>
                                <FaYoutube className='text-xl text-white' />
                            </div>
                        </div>
                    </div>

                </motion.div>
            </div>


        </div>
    );
}

export default Contactus;

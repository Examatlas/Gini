import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import LOGO from '../assets/logo-removebg-preview.png';
import { FaXmark } from 'react-icons/fa6';

const Header = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const {pathname}=useLocation();
   
    return (
        <header 
        className={` header bg-opacity-90 lg:px-[3rem] text-white shadow-md`}>
            <div className="container mx-auto px-4 py-4 flex justify-between items-center transition-all duration-700">
                {/* Logo */}
                <div className="logo flex justify-center items-center">
                    <img
                        src={LOGO}
                        alt="Logo"
                        className="w-12 h-12"
                    />
                    <span className='text-3xl font-roboto'>GINI</span>
                </div>

                {/* Desktop Navigation */}
                <nav className="hidden md:flex text-xl text-white font-roboto space-x-8">
                    <Link to="/" className={`hover:text-orange-500 ${pathname==='/'?"text-orange-500":"text-white"}`}>
                        Home
                    </Link>
                    <Link to="/services" className={`hover:text-orange-500 ${pathname==='/services'?"text-orange-500":"text-white"}`}>
                        Services
                    </Link>
                    <Link to="/about" className={`hover:text-orange-500 ${pathname==='/about'?"text-orange-500":"text-white"}`}>
                        About us
                    </Link>
                    <Link to="/contact" className={`hover:text-orange-500 ${pathname==='/contact'?"text-orange-500":"text-white"}`}>
                        Contact us
                    </Link>
                    {/* <Link to="/testimonials" className={`hover:text-orange-500 ${pathname==='/testimonials'?"text-orange-500":"text-white"}`}>
                        Testimonials
                    </Link> */}
                    {/* <Link to="/team" className={`hover:text-orange-500 ${pathname==='/team'?"text-orange-500":"text-white"}`}>
                        Team
                    </Link> */}
                    {/* <Link to="/blog" className={`hover:text-orange-500 ${pathname==='/blog'?"text-orange-500":"text-white"}`}>
                        Blog
                    </Link> */}
                </nav>

                <div className=' hidden md:block'>
                    <button className='px-6 py-2 rounded-3xl font-roboto bg-blue-600 hover:bg-blue-500 text-white'>Get Quotes</button>
                </div>

                {/* Mobile Menu Button */}
                <button
                    className="md:hidden flex items-center"
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                    <svg
                        className="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M4 6h16M4 12h16m-7 6h7"
                        ></path>
                    </svg>
                </button>

                {/* Mobile Navigation */}
                {isMenuOpen && (
                    <motion.nav 
                    initial={{ x: '100%' }}
                    animate={{ x: isMenuOpen ? '0%' : '100%' ,}} 
                    transition={{ type: 'tween', duration: isMenuOpen ? 0.7 : 1.2,ease: 'easeInOut'  }}
                    className={`fixed top-0 -right-[60rem] ${isMenuOpen ? "right-0" : ""}  w-full h-full bg-blue-800 shadow-lg z-50 `}>
                        <div className="logo absolute left-4 top-4 sm:left-16 flex justify-center items-center">
                            <img
                                src={LOGO}
                                alt="Logo"
                                className="w-12 h-12"
                            />
                            <span className='text-3xl font-roboto'>GINI</span>
                        </div>

                        <ul className="flex top-[20rem] h-full flex-col items-center justify-center space-y-4 py-6">
                            <li>
                                <Link
                                    to="/"
                                    className={`${pathname==="/"?"text-orange-500":"text-white"} font-roboto hover:text-orange-500 font-medium text-lg`}
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Home
                                </Link>
                            </li>
                            <li>
                                <Link
                                    to="/services"
                                    className={`${pathname==="/services"?"text-orange-500":"text-white"} font-roboto hover:text-orange-500 font-medium text-lg`}
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Services
                                </Link>
                            </li>
                            <li>
                                <Link
                                    to="/about"
                                    className={`${pathname==="/about"?"text-orange-500":"text-white"} font-roboto hover:text-orange-500 font-medium text-lg`}
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    About us
                                </Link>
                            </li>
                            <li>
                                <Link
                                    to="/contact"
                                    className={`${pathname==="/contact"?"text-orange-500":"text-white"} font-roboto hover:text-orange-500 font-medium text-lg`}
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Contact Us
                                </Link>
                            </li>
                            {/* <li>
                                <Link
                                    to="/blog"
                                    className={`${pathname==="/blog"?"text-orange-500":"text-white"} font-roboto hover:text-orange-500 font-medium text-lg`}
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Blog
                                </Link>
                            </li> */}
                        </ul>
                        <div className=' absolute top-6 right-4 sm:right-16 cursor-pointer'>
                            <FaXmark className='text-3xl' onClick={() => setIsMenuOpen(!isMenuOpen)} />
                        </div>
                    </motion.nav>
                )}
            </div>
        </header>
    );
};

export default Header;

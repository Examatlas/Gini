import React, { useRef } from 'react';
import Button from '../common/Button';
import ServiceCard from '../common/ServiceCard';
import { motion, useInView } from 'framer-motion';

//services images
import AppDev from '../assets/services/apps.webp';
import webDev from '../assets/services/web.webp';
import digitalMarketing from '../assets/services/digital.webp';
import seo from '../assets/services/seo.webp';
import security from '../assets/services/security.webp';
import hosting from '../assets/services/hosting.webp';


const Services = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true });
    return (
        <>
            <div className='my-20 bg-white md:mx-[5rem] mx-[1rem] flex flex-col md:flex-row md:justify-between'>
                <motion.div
                    ref={ref}
                    initial={{ x: '-10vw', opacity: 0 }}
                    animate={isInView ? { x: 0, opacity: 1 } : {}}
                    transition={{ duration: 1.5, ease: 'easeInOut' }}
                    className=' w-full md:w-[70%]'>
                    <h3 className='text-2xl font-semibold text-orange-500 font-roboto'>Our Services</h3>
                    <h1 className='text-4xl font-bold text-slate-800 font-roboto my-4'>Services We Offer</h1>
                    <p className='font-roboto text-lg text-slate-700'>Technox is a HTML5 template based on Sass and Bootstrap 5 with modern and creative multipurpose design you can use Best services & IT solutions.</p>
                </motion.div>

                <motion.div
                    ref={ref}
                    initial={{ x: '10vw', opacity: 0 }} 
                    animate={isInView ? { x: 0, opacity: 1 } : {}}
                    transition={{ duration: 1.5, ease: 'easeInOut' }}
                    className=' mt-8 md:mt-16'>
                    <Button ButtonValue={'See Services'} path={'/services'} />
                </motion.div>
            </div>

            <div className='md:mx-[5rem] 2xl:mx-[10rem] mx-[1rem] grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6'>
                <ServiceCard
                    icons={AppDev}
                    title={'Apps Development'}
                    desc={'Bring your ideas to life with custom mobile and web applications. From design to deployment, we create high-performance, scalable solutions tailored to your business needs.'}
                />
                <ServiceCard
                    icons={webDev}
                    title={'Web Development'}
                    desc={'Build responsive, user-friendly websites that drive engagement and deliver seamless experiences across all devices.'}
                />
                <ServiceCard
                    icons={digitalMarketing}
                    title={'Digital Marketing'}
                    desc={'Boost your brand with targeted campaigns, social media strategy, and content that connects with your audience.'}
                />
                <ServiceCard
                    icons={seo}
                    title={'SEO Optimization'}
                    desc={'Optimize your website for search engines to improve visibility, drive traffic, and increase your ranking.'}
                />
                <ServiceCard
                    icons={hosting}
                    title={'Web Hosting'}
                    desc={'Reliable, fast, and secure hosting solutions that ensure your website is always online and accessible.'}
                />
                <ServiceCard
                    icons={security}
                    title={'Bulk SMS'}
                    desc={'Send high-delivery, instant messages to engage your audience effectively with Gini’s reliable Bulk SMS solutions.'}
                />

            </div>
        </>

    );
}

export default Services;

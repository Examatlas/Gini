import React, { useRef } from 'react';
import { motion,useInView } from 'framer-motion';

import chooseUs from '../assets/services/choose_us.webp'
import WhyChooseUsCard from '../common/WhyChooseUsCard';
import HighSecurity from '../assets/whyChoose/high-security.webp';
import team from '../assets/whyChoose/team.webp';
import price from '../assets/whyChoose/price.webp';
import support from '../assets/whyChoose/support.webp';

const WhyChooseUs = () => {
    const ref=useRef();
    const isInView=useInView(ref,{once:true});
    return (
        <div className='flex flex-col xl:flex-row'>
            <motion.div 
            ref={ref}
            initial={{ x: '-10vw', opacity: 0 }}
            animate={isInView ? { x: 0, opacity: 1 } : {}}
            transition={{ duration: 1.5, ease: 'easeInOut' }}
            className='w-full xl:w-1/2 '>
                <div className=' '>
                    <h3 className=' text-xl sm:text-2xl font-semibold text-orange-500 font-roboto'>Why Choose Us</h3>
                    <h1 className=' text-2xl sm:text-4xl w-full font-bold text-slate-700 opacity-90 font-roboto my-4'>
                        We provide perfect it solutions & technology for any startups.
                    </h1>

                    <p className=' text-lg font-roboto text-gray-800'>
                    At Gini, we provide top-tier IT solutions tailored for startups and businesses. Our expertise ensures your success with reliable, secure, and efficient technology.
                    </p>
                </div>

                <div className='my-4 grid grid-cols-1 md:grid-cols-2'>
                    <WhyChooseUsCard
                    icons={HighSecurity}
                    title={'High Security'}
                    desc={'We prioritize your data’s safety with advanced security protocols, protecting your systems from threats and ensuring peace of mind.'}
                    />
                    <WhyChooseUsCard
                    icons={team}
                    title={'Skilled Team'}
                    desc={'Our team of experts is equipped with the latest tech knowledge and creativity to deliver innovative, high-quality solutions that meet your business needs.'}
                    />
                    <WhyChooseUsCard
                    icons={price}
                    title={'Affordable Price'}
                    desc={`We offer cost-effective solutions that fit your budget without sacrificing quality, giving you the best value for your investment.`}
                    />
                    <WhyChooseUsCard
                    icons={support}
                    title={'24/7 Support'}
                    desc={'Our support team is available around the clock, ready to assist you at any time to ensure your project runs smoothly with quick, reliable service.'}
                    />
                </div>

            </motion.div>

            <motion.div 
            ref={ref}
            initial={{ x: '10vw', opacity: 0 }}
            animate={isInView ? { x: 0, opacity: 1 } : {}}
            transition={{ duration: 1.5, ease: 'easeInOut' }}
            className='w-full lg:w-1/2'>
                <img src={chooseUs} className='w-[85%] md:w-[95%]' alt="Why choose Us Image" />
            </motion.div>
        </div>
    );
}

export default WhyChooseUs;

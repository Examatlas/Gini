import React from 'react';
import { motion } from 'framer-motion';

//images
import BannerImage from '../assets/Banner.avif';

const Banner = () => {
    return (
        <div
            className='my-20 md:my-28'>
            {/* Bnaaer Images */}
            <div className='w-full absolute top-0 -z-50'>
                <img src={BannerImage} className='min-w-[20rem] w-full h-[100vh] mt-20 ' alt="Banner" />
            </div>
            {/* Bnaaer Content */}
            <motion.div
             initial={{ y: '10vh' }} 
             animate={{ y: 0 }} 
             transition={{ duration: 1.5, ease: 'easeInOut' }}
             className='flex w-full my-10'>
                <div className='w-full md:w-[60%] text-white flex justify-center items-center flex-col mx-8 md:mx-[5rem]'>
                    <h1 className='text-3xl sm:text-4xl w-full font-semibold md:text-5xl leading-10 md:mb-10'>
                        Boost Your Business with Advanced Software & Strategic Marketing!
                    </h1>
                    <p className='text-xl font-normal leading-8 text-gray-100'>
                        Unlock your potential with custom software and targeted marketing. Boost growth, conversions, and success with tailored solutions and real-time analytics.
                    </p>
                    <div className='w-full'>
                        <button className='my-5 px-6 py-2 rounded-3xl font-roboto bg-blue-600 text-white'>Get Started</button>
                    </div>
                    {/* <div className='flex space-x-6 w-full md:mt-10 mx-4' title='Facebook'>
                        <div className='bg-gray-100 rounded-full p-2 hover:bg-slate-200'>
                            <FaFacebook className='text-xl md:text-3xl text-blue-600 cursor-pointer rounded-full' />
                        </div>
                        <div className='bg-gray-100 rounded-full p-2 hover:bg-slate-200' title='Instagram'>
                            <FaInstagram className='text-xl md:text-3xl text-red-600 cursor-pointer' />
                        </div>
                        <div className='bg-gray-100 rounded-full p-2 hover:bg-slate-200' title='X-Twitter'>
                            <FaXTwitter className='text-xl md:text-3xl text-black cursor-pointer' />
                        </div>
                    </div> */}
                </div>
                <div className='hidden lg:block md:w-[40%] xl:[35%]'>
                    {/* <img src={BannerSide} alt="Banner" className='w-[40rem]' /> */}
                </div>
            </motion.div>
        </div>
    );
}

export default Banner;

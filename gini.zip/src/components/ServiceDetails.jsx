import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

import { TiTick } from "react-icons/ti";
import AppDeveloment from '../assets/services/App development.jpg';

export const ServiceDetailsLeft = ({img, title, heading, desc, feature1, feature2, feature3, feature4, }) => {
    const ref = useRef();
    const isInView = useInView(ref, { once: true });
    return (
        <div className='flex flex-col xl:flex-row lg:px-[5rem]'>
            <motion.div
                ref={ref}
                initial={{ x: '-10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className='w-full flex flex-col justify-center items-start xl:w-[60%] px-[1rem] py-10 lg:px-[5rem]'>
                <div className=' '>
                    <h3 className=' text-xl sm:text-2xl font-semibold text-orange-500 font-roboto'>{title}</h3>
                    <h1 className=' text-2xl sm:text-4xl w-full font-bold text-slate-700 opacity-90 font-roboto my-4'>
                        {heading}
                    </h1>
                    <p className=' text-lg font-roboto text-gray-800'>
                        {desc}
                    </p>
                </div>
                <div className='text-lg font-roboto text-slate-700'>
                    <h2 className='text-xl font-bold my-4'>Key Features</h2>
                    <ul>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature1}
                        </li>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature2}
                        </li>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature3}
                        </li>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature4}
                        </li>
                    </ul>
                </div>
            </motion.div>

            <motion.div
                ref={ref}
                initial={{ x: '10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className='w-full lg:w-[40%] flex justify-center items-center'>
                <img src={img} className='w-[100%]' alt="App development Image" />
            </motion.div>
        </div>
    );
};

export const ServiceDetailsRight = ({img, title, heading, desc, feature1, feature2, feature3, feature4, }) => {
    const ref = useRef();
    const isInView = useInView(ref, { once: true });
    return (
        <div className='flex flex-col xl:flex-row lg:px-[5rem]'>

            <motion.div
                ref={ref}
                initial={{ x: '10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className='w-full lg:w-[40%] flex justify-center items-center'>
                <img src={img} className='w-[100%]' alt="App development Image" />
            </motion.div>

            <motion.div
                ref={ref}
                initial={{ x: '-10vw', opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ duration: 1.5, ease: 'easeInOut' }}
                className='w-full flex flex-col justify-center items-start xl:w-[60%] px-[1rem] py-10 lg:px-[5rem]'>
                <div className=' '>
                    <h3 className=' text-xl sm:text-2xl font-semibold text-orange-500 font-roboto'>{title}</h3>
                    <h1 className=' text-2xl sm:text-4xl w-full font-bold text-slate-700 opacity-90 font-roboto my-4'>
                        {heading}
                    </h1>

                    <p className=' text-lg font-roboto text-gray-800'>
                        {desc}
                    </p>
                </div>
                <div className='text-lg font-roboto text-slate-700'>
                    <h2 className='text-xl font-bold my-4'>Key Features</h2>
                    <ul>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature1}
                        </li>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature2}
                        </li>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature3}
                        </li>
                        <li className='flex gap-2 justify-start items-center my-2'>
                            <TiTick className='text-2xl text-orange-600' /> {feature4}
                        </li>
                    </ul>
                </div>
            </motion.div>
        </div>
    );
};


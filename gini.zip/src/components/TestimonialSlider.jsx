import React from "react";
import Slider from "react-slick";

// import "react-slick/slic";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import TestimonialCard from "../common/TestimonialCard";

function TestimonialSlider() {
    var settings = {
        // dots: true,
        infinite: true,
        speed: 2000,
        slidesToShow: 3,
        slidesToScroll: 1,
        initialSlide: 0,
        autoplay: true,
        autoplaySpeed: 4000,
        cssEase: "linear",
        arrows:false,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    // dots: true
                }
            },
            {
                breakpoint: 800,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    // initialSlide: 0
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    return (
        <div className="slider-container my-12">
            <Slider {...settings}>
                <div>
                    <TestimonialCard
                    name={`Ramesh Gupta`}
                    work={`CEO, TechNova Solutions`}
                    desc={`Gini transformed our online presence with their cutting-edge web development services. Their team was professional, responsive, and delivered beyond our expectations. Highly recommend!`}
                     />
                </div>
                <div>
                    <TestimonialCard
                    name={` Priya Shah`}
                    work={`Marketing Head, NextGen Retail`}
                    desc={`The digital marketing strategies from Gini brought a remarkable 40% increase in our online sales. Their expertise and data-driven approach have been a game-changer for us.`}

                     />
                </div>
                <div>
                    <TestimonialCard
                    name={` Ankit Verma`}
                    work={`Founder, Verma Enterprises`}
                    desc={`We partnered with Gini for mobile app development, and they delivered an intuitive, user-friendly app that perfectly suits our business. The process was seamless, and the results were outstanding.`}

                     />
                </div>
                <div>
                    <TestimonialCard
                    name={`Meera Iyer`}
                    work={` GreenLeaf Organics`}
                    desc={`Gini’s Bulk SMS services have helped us reach our customers instantly and effectively. Their platform is easy to use, and their support team is always there when we need them`}
                    />
                </div>

                <div>
                <TestimonialCard
                name={`Vikram Rao`}
                work={`CTO, Dynamic Logistics`}
                desc={`From cloud solutions to IT consulting, Gini has been our go-to partner for all things tech. Their services have streamlined our operations and improved our overall efficiency.`}
                />
                </div>

                <div>
                <TestimonialCard
                name={`Shalini Deshmukh`}
                work={`Director, EduTech India`}
                desc={`The SEO services provided by Gini significantly boosted our website traffic. We saw a 200% increase in organic traffic within months. Truly impressed by their professionalism and expertise.`}
                />
                </div>
                {/* <TestimonialCard/>
                <TestimonialCard/>
                <TestimonialCard/>
                <TestimonialCard/> */}

            </Slider>
        </div>
    );
}

export default TestimonialSlider;

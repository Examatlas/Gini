import React from 'react';
import PageBanner from '../common/PageBanner';

import { ServiceDetailsLeft, ServiceDetailsRight } from '../components/ServiceDetails';
//img
import appDevimg from '../assets/services/App development.jpg';
import webdevImg from '../assets/services/web development.avif';
import digitalMarketingImg from '../assets/services/digital marketing.avif';
import seoOptimization from '../assets/services/seo-optimazation.avif';
import webHoistingImg from '../assets/services/web-hoisting.jpg';
import bulkSmsImg from '../assets/services/bulk-sms.avif';
const Services = () => {
  return (
    <div>
      <PageBanner
        title={'Services'}
        desc={'Looking for reliable software services? Our platform offers custom software solutions, cloud integration, data analytics, and seamless API development to meet your business needs. Optimize workflows, boost efficiency, and scale your operations with our expert support.'}
      />
      <div className=''>
        <ServiceDetailsLeft
        img={appDevimg}
          title={`App Development`}
          heading={`Transform Your Ideas into Powerful Applications`}
          desc={`We design and develop innovative mobile applications for iOS and Android platforms. Our approach ensures seamless user experiences, tailored to meet your business needs and engage your audience effectively.`}
          feature1={`Custom app design and development`}
          feature2={`Cross-platform compatibility`}
          feature3={`User-friendly interfaces`}
          feature4={`Integration with third-party APIs`}
        />
        <ServiceDetailsRight
        img={webdevImg}
          title={`Web Development`}
          heading={`Transform Your Vision into a Stunning Website`}
          desc={`Our web development services encompass everything from corporate websites to complex web applications. We leverage modern technologies to create responsive, fast, and secure websites that drive business growth.`}
          feature1={`Responsive web design`}
          feature2={`E-commerce solutions`}
          feature3={`Content management systems (CMS)`}
          feature4={`SEO optimization`}
        />
        <ServiceDetailsLeft
        img={digitalMarketingImg}
          title={`Digital Marketing`}
          heading={`Transform Your Brand’s Online Presence`}
          desc={`At Gini, our digital marketing services empower businesses to reach their target audience effectively. We utilize data-driven strategies across various channels to enhance your online presence and drive measurable results. From social media management to email marketing, our tailored solutions ensure that your brand stands out in the crowded digital landscape.`}
          feature1={`Comprehensive digital marketing strategy`}
          feature2={`Social media management and advertising`}
          feature3={`Pay-Per-Click (PPC) campaigns`}
          feature4={`Content marketing and email campaigns`}
        />
        <ServiceDetailsRight
        img={seoOptimization}
          title={`SEO Optimization`}
          heading={`Boost Your Visibility and Traffic`}
          desc={`Our SEO optimization services help your website rank higher on search engines, driving organic traffic and improving visibility. We conduct thorough keyword research, optimize on-page elements, and implement technical SEO best practices to ensure your site is search-engine friendly. With our ongoing analysis and reporting, we adapt strategies to keep you ahead of the competition.`}
          feature1={`Comprehensive keyword research`}
          feature2={`On-page SEO optimization`}
          feature3={`Technical SEO audits and improvements`}
          feature4={`Monthly performance reporting`}
        />
        <ServiceDetailsLeft
        img={webHoistingImg}
          title={`Web Hosting`}
          heading={`Power Your Website with Reliable Hosting`}
          desc={`We offer reliable and secure web hosting solutions tailored to your business needs. Our hosting services include shared, VPS, and dedicated options, ensuring fast loading times, high uptime, and robust security features. With 24/7 technical support and easy scalability, we provide the perfect environment for your website to thrive.`}
          feature1={`Shared, VPS, and dedicated hosting options`}
          feature2={`99.9% uptime guarantee`}
          feature3={`Free SSL certificate for enhanced security`}
          feature4={`24/7 customer support`}
        />
        <ServiceDetailsRight
        img={bulkSmsImg}
          title={`Bulk SMS`}
          heading={`Connect Instantly with Your Audience`}
          desc={`Our Bulk SMS service allows you to reach your customers instantly and efficiently. With high delivery rates and a user-friendly platform, you can send promotional messages, alerts, and notifications effortlessly. Customize your messages and analyze campaign performance with our detailed reporting tools to enhance customer engagement.`}
          feature1={`High delivery rates and reliability`}
          feature2={`Scheduled messaging and automation`}
          feature3={`Customizable message templates`}
          feature4={`Detailed analytics and reporting`}
        />
      </div>
    </div>
  );
}

export default Services;

import React from 'react';
import PageBanner from '../common/PageBanner';
import Contactus from '../components/Contactus';

const Contact = () => {
  return (
    <div>
      <PageBanner title={`Contact Us`} desc={`Empowering your growth with cutting-edge technology, custom software, and digital strategies. Let's transform your vision into reality.`}/>

      <div>
        <Contactus/>
      </div>
    </div>
  );
}

export default Contact;

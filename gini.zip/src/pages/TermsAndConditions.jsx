import React from "react";

const TermsAndConditions = () => {
  return (
    <div className="terms-conditions-container py-12 px-6 lg:px-24 bg-gray-50 text-gray-800">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">Terms & Conditions</h1>

        {/* Introduction Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Introduction</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Welcome to Gini. By accessing and using our services, you agree to comply
            with and be bound by the following terms and conditions. Please read them
            carefully as they govern your use of our website and services.
          </p>
        </section>

        {/* Use of Services Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Use of Our Services</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Our services are intended for lawful purposes only. By using our website
            and services, you agree not to:
          </p>
          <ul className="list-disc list-inside text-lg text-gray-700 leading-relaxed space-y-2">
            <li>Engage in any illegal activity or violate any applicable laws or regulations.</li>
            <li>Transmit harmful or malicious software.</li>
            <li>Interfere with or disrupt the security of our services.</li>
          </ul>
        </section>

        {/* User Responsibilities Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">User Responsibilities</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            As a user, you are responsible for maintaining the confidentiality of any
            personal information associated with your account and for restricting access
            to your computer to prevent unauthorized use of our services.
          </p>
        </section>

        {/* Intellectual Property Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Intellectual Property</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            All content, including text, graphics, logos, and software, is the property
            of Gini or its licensors and is protected by copyright laws. You may not
            reproduce, distribute, or create derivative works from any part of the website
            without our written consent.
          </p>
        </section>

        {/* Limitation of Liability Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Limitation of Liability</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Gini will not be liable for any damages, including but not limited to,
            incidental, direct, indirect, or consequential damages resulting from the use
            or inability to use our services, even if we have been advised of the
            possibility of such damages.
          </p>
        </section>

        {/* Changes to Terms Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Changes to These Terms</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Gini reserves the right to update or modify these terms at any time. Any
            changes will be effective immediately upon posting on this page. Continued use
            of our services after any such changes indicates your acceptance of the new
            terms.
          </p>
        </section>

        {/* Governing Law Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Governing Law</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            These terms are governed by and construed in accordance with the laws of India,
            without regard to its conflict of law principles.
          </p>
        </section>

        {/* Contact Information */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            If you have any questions about these Terms & Conditions, please contact us at:
          </p>
          <p className="text-lg text-gray-700 leading-relaxed font-medium mt-4">
            Email: terms@gini.com <br />
            Phone: +91-123-456-7890
          </p>
        </section>

        {/* Footer Disclaimer
        <section className="text-center mt-12">
          <p className="text-lg text-gray-500">
            Last Updated: October 7, 2024
          </p>
        </section> */}
      </div>
    </div>
  );
};

export default TermsAndConditions;

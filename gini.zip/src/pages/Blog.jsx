import React from 'react';
import PageBanner from '../common/PageBanner';
import Blogs from '../components/Blogs';

const Blog = () => {
  return (
    <div>
      <PageBanner
      title={'Blogs'}
      desc={'Discover how custom software can boost efficiency, streamline workflows, and drive business growth.'}
      />
      <div className='w-[97%] sm:w-[90%] lg:w-[80%] mx-auto'>
        <Blogs/>
      </div>
    </div>
  );
}

export default Blog;

import React from 'react';
import PageBanner from '../common/PageBanner';
import Testimonial from '../components/Testimonial';

const Testimonials = () => {
  return (
    <div>
      <PageBanner title={'Testimonials'} desc={'Transformed our business with seamless software solutions'}/>

      <div>
        <Testimonial/>
      </div>
    </div>
  );
}

export default Testimonials;

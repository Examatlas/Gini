import React from 'react';
import Banner from '../components/Banner';
import Services from '../components/Services';
import OurProcess from '../components/OurProcess';
import WhyChooseUs from '../components/WhyChooseUs';
import OurPortfolio from '../components/OurPortfolio';
import Testimonial from '../components/Testimonial';
import Contactus from '../components/Contactus';
import FAQs from '../components/FAQs';

const Home = () => {
  return (
    <div>
      <Banner />
      <div className='mt-[10rem] md:mt-[3rem] mx-auto mb-20 bg-white py-5'>
        <Services />
      </div>
      <div className=' '>
        <OurProcess />
      </div>
      <div className='w-[90%] lg:w-[80%] mx-auto py-10'>
        <WhyChooseUs/>
      </div>
      {/* <div className='w-[100%] lg:w-[80%] mx-auto py-10'> */}
        {/* <OurPortfolio/> */}
      {/* </div> */}

      <div>
        <Testimonial/>
      </div>

      <div>
        <FAQs/>
      </div>

      <div>
        <Contactus />
      </div>
    </div>
  );
}

export default Home;

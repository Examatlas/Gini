import React from "react";

const PrivacyPolicy = () => {
  return (
    <div className="privacy-policy-container py-12 px-6 lg:px-24 bg-gray-50 text-gray-800">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">Privacy Policy</h1>

        {/* Introduction Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Introduction</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            At Gini, your privacy is our priority. We are committed to
            safeguarding any personal information you share with us and ensuring
            transparency about how we collect, use, and protect your data. This
            Privacy Policy outlines our practices regarding your information and
            how we ensure its security.
          </p>
        </section>

        {/* Data Collection Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Data We Collect</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Gini collects various types of information to provide the best
            possible experience for our clients. This includes personal details
            like your name, email address, and phone number, as well as
            technical data such as IP addresses, browser information, and usage
            patterns when you interact with our website.
          </p>
        </section>

        {/* How We Use Your Data */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">How We Use Your Data</h2>
          <ul className="list-disc list-inside text-lg text-gray-700 leading-relaxed space-y-2">
            <li>To provide and improve our services.</li>
            <li>To communicate with you regarding updates, offers, and promotions.</li>
            <li>To understand your needs and enhance user experience.</li>
            <li>To maintain the security of our services and prevent fraud.</li>
          </ul>
        </section>

        {/* Data Sharing */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Data Sharing</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            We do not share your personal data with third parties except in the
            following cases:
          </p>
          <ul className="list-disc list-inside text-lg text-gray-700 leading-relaxed space-y-2">
            <li>When required by law or government authorities.</li>
            <li>To trusted partners who help us operate our services, under strict confidentiality.</li>
            <li>To prevent illegal activities, fraud, or to ensure the security of Gini and its users.</li>
          </ul>
        </section>

        {/* Data Security */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Data Security</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            We prioritize the security of your data and employ advanced security
            measures, such as encryption, firewalls, and access controls, to
            ensure its protection. Our systems are regularly monitored and
            updated to safeguard against unauthorized access or data breaches.
          </p>
        </section>

        {/* Your Rights */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Your Rights</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            You have the right to access, correct, or delete your personal
            information at any time. If you wish to exercise any of your rights,
            please contact us, and we will respond promptly. We also offer the
            option to unsubscribe from marketing communications if you no longer
            wish to receive them.
          </p>
        </section>

        {/* Cookies Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Cookies</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Our website uses cookies to enhance your browsing experience by
            remembering your preferences and tracking website usage. You can
            manage your cookie settings or disable them in your browser at any
            time. However, some features of our website may not function
            properly without cookies.
          </p>
        </section>

        {/* Contact Information */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            If you have any questions or concerns regarding our Privacy Policy
            or your data, please contact us at:
          </p>
          <p className="text-lg text-gray-700 leading-relaxed font-medium mt-4">
            Email: privacy@gini.com <br />
            Phone: +91-123-456-7890
          </p>
        </section>

        {/* Footer Disclaimer
        <section className="text-center mt-12">
          <p className="text-lg text-gray-500">
            Last Updated: October 7, 2024
          </p>
        </section> */}
      </div>
    </div>
  );
};

export default PrivacyPolicy;

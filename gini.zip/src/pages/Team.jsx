import React from 'react';
import PageBanner from '../common/PageBanner';
import OurPortfolio from '../components/OurPortfolio';

const Team = () => {
  return (
    <div>
      <PageBanner 
      title={'Our Team'} 
      desc={`A dedicated group of experts, our team brings together innovation, experience, and passion to deliver top-tier software solutions. We're here to help your business succeed.`}/>

      <div className='py-20'>
        <OurPortfolio/>
      </div>
    </div>
  );
}

export default Team;

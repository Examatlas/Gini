import React from 'react';

import banner from '../assets/Banner.jpeg'

const PageBanner = ({title,desc}) => {
    return (
        <div className='relative text-white w-full -z-50'>
            <div className='w-full h-[30rem] '>
                <img src={banner} alt="Banenr" className='w-full h-full' />
            </div>
            <div className='absolute top-0 bottom-0 left-0 right-0 mx-auto w-full md:w-[50%] h-[50%] my-auto p-5'>
                <h1 className='text-4xl text-center font-roboto text-orange-600 font-medium my-5'>{title}</h1>
                <p className='text-center text-lg font-roboto text-gray-100'>{desc}</p>
            </div>

            <div className='bg-blue-600 text-white px-5 md:px-20 py-4'>
                <span className='text-lg font-roboto'>Home</span>{" > "} <span className='text-lg font-roboto text-orange-400 font-medium'>{title}</span>
            </div>
        </div>
    );
}

export default PageBanner;

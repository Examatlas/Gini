import React from 'react';
import { FaStar } from 'react-icons/fa6';

import img from '../assets/user.jpeg';
const TestimonialCard = ({name,work,desc,image}) => {
  return (
    <div className='bg-blue-800 bg-opacity-30 h-[25rem] text-gray-100 mx-4 p-9 border rounded-3xl'>
      <div className='flex gap-4 my-4'>
        <div>
            <img src={img} className='w-[5rem] rounded-full h-[5rem]' alt="Client image" />
        </div>
        <div>
            <h1 className='text-2xl font-roboto font-semibold leading-5'>{name}</h1>
            <p>{work}</p>
            <div className='flex gap-2 my-4'>
                <FaStar className='text-orange-500'/>
                <FaStar className='text-orange-500'/>
                <FaStar className='text-orange-500'/>
                <FaStar className='text-orange-500'/>
                <FaStar className='text-orange-500'/>
            </div>
        </div>
      </div>
      <div className='text-lg font-roboto'>
        {desc}
      </div>
    </div>
  );
}

export default TestimonialCard;

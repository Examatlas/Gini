import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const ServiceCard = ({ icons, title, desc }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <motion.div
      ref={ref}
      initial={{ y: '30vh', opacity: 0 }} 
      animate={isInView ? { y: 0, opacity: 1 } : {}} 
      transition={{
        type: 'spring',  
        duration: 1.5,
        ease: 'easeInOut'  
      }}
      className='w-full mx-auto'>
      <div className='w-[21rem] mx-auto h-[21rem] md:w-[24rem] md:h-[24rem] flex flex-col justify-center items-center px-10 py-10 hover:bg-blue-50 '>
        <img src={icons} alt="APP development logo" />
        <h2 className='text-center text-xl font-semibold my-2 font-roboto'>{title}</h2>
        <p className='text-center font-roboto text-lg'>{desc}</p>
      </div>
    </motion.div>
  );
}

export default ServiceCard;

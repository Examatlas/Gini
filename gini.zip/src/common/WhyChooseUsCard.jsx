import React from 'react';

const WhyChooseUsCard = ({icons,title,desc}) => {
  return (
    <div className='w-full mx-auto'>
      <div className='w-[15rem] h-[15rem] mx-auto flex flex-col justify-start items-start px-2 py-4 '>
        <img src={icons} alt="" />
        <h2 className=' text-xl font-semibold opacity-90 text-slate-700 my-2 font-roboto'>{title}</h2>
        <p className=' font-roboto text-sm text-slate-700'>{desc}</p>
      </div>
    </div>
  );
}

export default WhyChooseUsCard;

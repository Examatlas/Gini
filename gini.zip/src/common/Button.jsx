import React from 'react';
import { Link } from 'react-router-dom';

const Button = ({ ButtonValue, path }) => {
  return (
    <div>
      <Link to={path?path:"/"}>
        <button className='my-5 px-6 py-3 rounded-full font-roboto bg-blue-600 hover:bg-blue-500 text-lg text-white'>{ButtonValue}</button>
      </Link>
    </div>
  );
}

export default Button;

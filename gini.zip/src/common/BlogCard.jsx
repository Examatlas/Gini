import React, { useRef } from 'react';
import { motion,useInView } from 'framer-motion';

const BlogCard = ({ title, description, imageUrl, date, link }) => {
  const ref=useRef();
  const isInView=useInView(ref,{once:true});
  return (
    <motion.div
    // <div
    ref={ref}
      className="max-w-sm rounded overflow-hidden shadow-lg bg-white"
      whileHover={{ scale: 1.05 }} 
      initial={{ opacity: 0, y: 50 }} 
      animate={isInView?{ opacity: 1, y: 0 }:{}} 
      transition={{ duration: 1.5 }} 
    >
      {/* Image */}
      <img className="w-full h-48 object-cover" src={imageUrl} alt={title} />
      
      {/* Content */}
      <div className="px-6 py-4">
        <div className="font-bold text-xl mb-2">{title}</div>
        <p className="text-gray-700 text-base">
          {description}
        </p>
      </div>

      {/* Footer */}
      <div className="px-6 pt-4 pb-2">
        <span className="text-sm text-gray-500">{date}</span>
        <a href={link} className="text-blue-500 hover:underline ml-4">
          Read more
        </a>
      </div>
    </motion.div>
    // </div>
  );
};

export default BlogCard;

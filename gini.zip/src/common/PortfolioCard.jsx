const PortfolioCard = ({ title, description, techStack, ctaText, image }) => {
    return (
      <div className="bg-white shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
        <img src={image} alt={title} className="w-full h-48 object-cover" />
        <div className="p-6">
          <h3 className="text-xl font-bold mb-3">{title}</h3>
          <p className="text-gray-600 mb-4">{description}</p>
          <p className="text-sm text-gray-500 mb-4"><span className="text-bold font-roboto text-lg">Tech Stack:</span> {techStack}</p>
          <button className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition">
            {ctaText}
          </button>
        </div>
      </div>
    );
};

export default PortfolioCard;
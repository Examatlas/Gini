import React from 'react';

import img from '../assets/BannerSide.png'
const OurProductCard = () => {
  return (
    <div>
      <div className='w-[20] h-[19rem] cursor-pointer relative group-hover:bottom-0 overflow-hidden transition-all duration-700  parents'>
            <img src={img} alt="Product Image" className='w-full h-full' />

            <div className='absolute bg-white -bottom-16 child w-full py-4 px-4'>
                <h2 className='text-blue-600 font-roboto text-center text-xl font-medium'>App for Virtual Reality</h2>
                <p className='text-center'>App Development</p>
            </div>
      </div>
    </div>
  );
}

export default OurProductCard;

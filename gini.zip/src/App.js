import logo from "./logo.svg";
import "./App.css";
import Header from "./components/Header";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Footer from "./components/Footer";
import Services from "./pages/Services";
import Testimonials from "./pages/Testimonials";
import Team from "./pages/Team";
import Blog from "./pages/Blog";
import Contact from "./pages/Contact";
import AboutUs from "./components/Aboutus";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsAndConditions from "./pages/TermsAndConditions";

function App() {
  return (
    <div className="">
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/services" element={<Services/>}/>
          <Route path="/testimonials" element={<Testimonials/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/about" element={<AboutUs/>}/>
          <Route path="/blog" element={<Blog/>}/>

          <Route path="/privacy-policy" element={<PrivacyPolicy/>}/>
          <Route path="/term&condition" element={<TermsAndConditions/>}/>
        </Routes>
        <Footer/>
      </BrowserRouter>
    </div>
  );
}

export default App;

export const blogPosts = [
    {
      title: "How Custom Software Can Boost Your Business",
      description: "Discover the ways custom software solutions can streamline your business and drive growth.",
      imageUrl: "https://via.placeholder.com/300",
      date: "October 4, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
    {
      title: "Top 5 Trends in Software Development",
      description: "Learn about the latest trends shaping the software development industry in 2024.",
      imageUrl: "https://via.placeholder.com/300",
      date: "September 28, 2024",
      link: "#"
    },
  ];
  
  
  